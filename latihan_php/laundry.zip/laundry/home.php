<?php
include "header.php";
?>
<h2>Selamat datang <?= $_SESSION['nama'] ?> di website Perpus Online.</h2>
<?php
include "footer.php";
?>